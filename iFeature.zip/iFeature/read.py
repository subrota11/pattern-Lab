import pandas as pd 
re=pd.read_csv("AAC.csv") 
print(re.iloc[0,0])